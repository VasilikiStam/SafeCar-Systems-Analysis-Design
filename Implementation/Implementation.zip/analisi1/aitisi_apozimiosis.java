package analisi1;

public class aitisi_apozimiosis extends aitisi {
	
	int _atiximata;
	
	katalogos_aitiseon_apozimiosis kata_ait_aposi=new katalogos_aitiseon_apozimiosis();
	
	public aitisi_apozimiosis(int _id, boolean _katastasi, pelatis _pelatis, oxima _oxima, praktoras _praktoras,int atiximata)
	{
		super();
		_atiximata=atiximata;
		kata_ait_aposi.add_aitisis(this);
	}

	
}