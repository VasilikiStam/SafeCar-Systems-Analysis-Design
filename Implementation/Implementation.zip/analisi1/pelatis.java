package analisi1;

public class pelatis {
	
 private String onomateponimo;
 private String imerominia_gennisis;
 private String diefthinsi;
 private String ar_dip_odigisis;
 private int atiximata;
 private int id;
 private boolean akatastasi_ofeilis;
 
 

 public pelatis (String ponomateponimo,String pimerominia_gennisis
		 ,String pdiefthinsi,String par_dip_odigisis,
		 int patiximata,int pid) {
	 onomateponimo=ponomateponimo;
	 imerominia_gennisis=pimerominia_gennisis;
	 diefthinsi=pdiefthinsi;
	 ar_dip_odigisis=par_dip_odigisis;
	 atiximata=patiximata;
	 id=pid;
	 
 }
 public String get_onomateponimo() {
	 return this.onomateponimo; 
 }
 
 public int get_id(){
	 return this.id;
 }
 public int get_atiximata() {
	 return this.atiximata;
 }
 public void increase_atiximata() {
	 this.atiximata++;
 }
 public String get_imerominia_gennisis() {
	 return this.imerominia_gennisis;
 }
 public String get_diefthinsi() {
	 return this.diefthinsi;
 }
 public String get_ar_dip_odigisis() {
	 return this.ar_dip_odigisis;
 }
 public void set_katastasi_ofeilis(boolean katastasi_ofeilis) {
	 this.akatastasi_ofeilis=katastasi_ofeilis;
	 
 }
 
 
 
 
}
