package analisi1;

import java.util.*;

public class katalogos_aitiseon_asfaliseon extends katalogos_aitiseon{
	private ArrayList<aitisi_asfalisis> aitiseis_asfaliseon ;

	public katalogos_aitiseon_asfaliseon() {
		aitiseis_asfaliseon = new ArrayList<aitisi_asfalisis>();
	}
	
	
}