package analisi1;


public class oxima {
   private String ar_kikloforias;
   private String marka;
   private String montelo;
   private float kivika_ek;
   private String xroma;
   private int id;
   
   public oxima (String par_kikloforias) {
	   ar_kikloforias=par_kikloforias;
   }
   public oxima (String par_kikloforias,String pmarka) {
	   ar_kikloforias=par_kikloforias;
	   marka=pmarka;
   }
   public oxima (String par_kikloforias,String pmarka
		   ,String pmontelo) {
	   ar_kikloforias=par_kikloforias;
	   marka=pmarka;
	   montelo=pmontelo;
   }
   public oxima (String par_kikloforias,String pmarka
		   ,String pmontelo,float pkivika_ek) {
	   ar_kikloforias=par_kikloforias;
	   marka=pmarka;
	   montelo=pmontelo;
	   kivika_ek=pkivika_ek;
   }
   public oxima (String par_kikloforias,String pmarka
		   ,String pmontelo,float pkivika_ek,String pxroma) {
	   ar_kikloforias=par_kikloforias;
	   marka=pmarka;
	   montelo=pmontelo;
	   kivika_ek=pkivika_ek;
       xroma=pxroma;
   }
   public oxima (String par_kikloforias,String pmarka
		   ,String pmontelo,float pkivika_ek,
		   String pxroma,int pid) {
	   ar_kikloforias=par_kikloforias;
	   marka=pmarka;
	   montelo=pmontelo;
	   kivika_ek=pkivika_ek;
       xroma=pxroma;
       id=pid;
   }
   public String getAr_kikloforias() {
       return ar_kikloforias;
   }

   public String getMarka() {
       return marka;
   }

   public String getMontelo() {
       return montelo;
   }

   public float getKivika_ek() {
       return kivika_ek;
   }

   public String getXroma() {
       return xroma;
   }

   public int getId() {
       return id;
   }

  
}

