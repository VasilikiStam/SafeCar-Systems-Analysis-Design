package analisi1;

public class aitisi {
	private int _id;
	private boolean _katastasi;
	private pelatis _pelatis;
	private oxima _oxima;
	private praktoras _praktoras;
	private float _poso_ofeilis;
	private paketo_asfalisis _paketo_asfalisis;
	private String _enarxi_asfaleias;
	private String _lixi_asfaleias;
	private boolean _katastasi_ofeilis;
	private asfalisi _asfalisi;
	private katalogos_pelaton kata_pel = new katalogos_pelaton();
	private katalogos_oximaton kata_oxima= new katalogos_oximaton();
	private katalogos_aitiseon kata_aitiseis = new katalogos_aitiseon();

	public int get_id() {
		return this._id;
	}

	public boolean get_katastasi() {
		return this._katastasi;
	}

	public void set_katastasi(boolean aKatastasi) {
		this._katastasi=aKatastasi;
		
		if(_katastasi)
		{	if (!kata_pel.check_pelatis(_pelatis))
				kata_pel.add_pelatis(_pelatis);
		
			if (!kata_oxima.check_oxima(_oxima))
				kata_oxima.add_oxima(_oxima);
			 _asfalisi=new asfalisi(_pelatis,_oxima,_praktoras,_paketo_asfalisis,_poso_ofeilis,_enarxi_asfaleias,_katastasi_ofeilis);
		}
		
	}

	public void set_pelatis(pelatis _pelatis) {
		this._pelatis = _pelatis;
	}

	public praktoras get_praktoras() {
		return _praktoras;
	}

	public void set_praktoras(praktoras _praktoras) {
		this._praktoras = _praktoras;
	}

	
	public oxima get_oxima() {
		return _oxima;
	}

	public void set_oxima(oxima _oxima) {
		this._oxima = _oxima;
	}

	public float get_poso_ofeilis() {
		return _poso_ofeilis;
	}

	public void set_poso_ofeilis(float _poso_ofeilis) {
		this._poso_ofeilis = _poso_ofeilis;
	}

	public paketo_asfalisis get_paketo_asfalisis() {
		return _paketo_asfalisis;
	}

	public void set_paketo_asfalisis(paketo_asfalisis _paketo_asfalisis) {
		this._paketo_asfalisis = _paketo_asfalisis;
	}

	public String get_enarxi_asfaleias() {
		return _enarxi_asfaleias;
	}

	public void set_enarxi_asfaleias(String _enarxi_asfaleias) {
		this._enarxi_asfaleias = _enarxi_asfaleias;
	}

	public String get_lixi_asfaleias() {
		return _lixi_asfaleias;
	}

	public void set_lixi_asfaleias(String _lixi_asfaleias) {
		this._lixi_asfaleias = _lixi_asfaleias;
	}

	public boolean is_katastasi_ofeilis() {
		return _katastasi_ofeilis;
	}

	public void set_katastasi_ofeilis(boolean _katastasi_ofeilis) {
		this._katastasi_ofeilis = _katastasi_ofeilis;
	}

	public pelatis get_pelatis() {
		return _pelatis;
	}

	public aitisi(int _id, float _poso_ofeilis, boolean _katastasi ,paketo_asfalisis _paketo_asfalisis, String _enarxi_asfaleias,
			String _lixi_asfaleias, pelatis _pelatis, oxima _oxima, boolean _katastasi_ofeilis, praktoras _praktoras) {
		this._id = _id;
		this._poso_ofeilis = _poso_ofeilis;
		this._paketo_asfalisis = _paketo_asfalisis;
		this._enarxi_asfaleias = _enarxi_asfaleias;
		this._lixi_asfaleias = _lixi_asfaleias;
		this._pelatis = _pelatis;
		this._oxima = _oxima;
		this._katastasi_ofeilis = _katastasi_ofeilis;
		this._praktoras = _praktoras;
	
	}
		
	
}