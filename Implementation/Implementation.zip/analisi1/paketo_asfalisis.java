package analisi1;
import java.util.*;

public class paketo_asfalisis {
	
	int id;
	float kostos;
	int plithos_poliseon;
	
	public paketo_asfalisis(int id, float kostos, int plithos_poliseon) {
		
		System.out.println ("Parakalw eisagete to id tou paketou");
		this.id = id;
		System.out.println ("Parakalw eisagete to kostos tou paketou");
		this.kostos = kostos;
		this.plithos_poliseon = 0;
	}
	
	void printData() {
		System.out.println("To paketo me id "+ id+ " exei kostos " + kostos+" kai plithos poliseon " +plithos_poliseon +"." );
	}

}
