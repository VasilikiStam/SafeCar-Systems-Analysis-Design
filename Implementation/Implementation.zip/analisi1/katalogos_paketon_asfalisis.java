package analisi1;

import java.util.*;

public class katalogos_paketon_asfalisis {
	
	ArrayList<paketo_asfalisis> paketa_asfalisis = new ArrayList();

	
	void add (paketo_asfalisis paketo) {
		paketa_asfalisis.add(paketo);
	}
	
	boolean search (int id) {
		int size = paketa_asfalisis.size();
		for(int i=0; i<size; i++) {
			if (id == paketa_asfalisis.get(i).id ) {
				return true;
			}
		}
		return false;
	}
	
	void remove (paketo_asfalisis paketo) {
		paketa_asfalisis.remove(paketo);
	}
	
	
}
