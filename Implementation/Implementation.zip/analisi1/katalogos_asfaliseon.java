package analisi1;
import java.util.*;

public class katalogos_asfaliseon {
	
	private ArrayList<asfalisi> asfaliseis ;

	public katalogos_asfaliseon() {
		asfaliseis =new ArrayList<asfalisi>();
	}
	public boolean check_id_asfalisis(int aId) {
		for(int i=0; i<asfaliseis.size();i++)
			if(asfaliseis.get(i).get_id() == aId)
				return true;
		return false;
	}
	public asfalisi search(int id)
	{
		for(int i=0; i<asfaliseis.size();i++)
			if(asfaliseis.get(i).get_id() == id)
				return asfaliseis.get(i);
	}

	public void get_posa_ofeilis(ArrayList posa) {
		for(int i=0; i<asfaliseis.size();i++)
			posa.add(asfaliseis.get(i).get_poso_ofeilis());
		
	}

	public void get_onomateponimo(ArrayList aOnomateponima) {
		for(int i=0; i<asfaliseis.size();i++)
			aOnomateponima.add(asfaliseis.get(i).get_pelatis().get_onomateponimo());
	}

	public void get_pelates(ArrayList aOfeilountes) {
		for(int i=0; i<asfaliseis.size();i++)
			if(asfaliseis.get(i).is_katastasi_ofeilis())
				aOfeilountes.add(asfaliseis.get(i).get_pelatis());
	}

	public void get_id_asfaliseon(ArrayList id_asfaliseon) {
		for(int i=0; i<asfaliseis.size();i++)
			id_asfaliseon.add(asfaliseis.get(i).get_id());
	}

	public void add_asfalisi(asfalisi aAsfaliseis) {
		asfaliseis.add(aAsfaliseis);
	}
}