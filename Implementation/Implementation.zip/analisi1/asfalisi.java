package analisi1;

public class asfalisi {
	private int _id;
	private float _poso_ofeilis;
	private paketo_asfalisis _paketo_asfalisis;
	private String _enarxi_asfaleias;
	private String _lixi_asfaleias;
	private pelatis _pelatis;
	private oxima _oxima;
	private boolean _katastasi_ofeilis;
	private praktoras _praktoras;
	katalogos_asfaliseon kata_asf=new katalogos_asfaliseon();
	private ofeili _ofeili;
	
	public int get_id() {
		return _id;
	}
	public void set_id(int _id) {
		this._id = _id;
	}
	public float get_poso_ofeilis() {
		return _poso_ofeilis;
	}
	public void set_poso_ofeilis(float _poso_ofeilis) {
		this._poso_ofeilis = _poso_ofeilis;
	}
	public paketo_asfalisis get_paketo_asfalisis() {
		return _paketo_asfalisis;
	}
	public void set_paketo_asfalisis(paketo_asfalisis _paketo_asfalisis) {
		this._paketo_asfalisis = _paketo_asfalisis;
	}
	public String get_enarxi_asfaleias() {
		return _enarxi_asfaleias;
	}
	public void set_enarxi_asfaleias(String _enarxi_asfaleias) {
		this._enarxi_asfaleias = _enarxi_asfaleias;
	}
	public String get_lixi_asfaleias() {
		return _lixi_asfaleias;
	}
	public void set_lixi_asfaleias(String _lixi_asfaleias) {
		this._lixi_asfaleias = _lixi_asfaleias;
	}
	public pelatis get_pelatis() {
		return _pelatis;
	}
	public void set_pelatis(pelatis _pelatis) {
		this._pelatis = _pelatis;
	}
	public oxima get_oxima() {
		return _oxima;
	}
	public void set_oxima(oxima _oxima) {
		this._oxima = _oxima;
	}
	public boolean is_katastasi_ofeilis() {
		return _katastasi_ofeilis;
	}
	public void set_katastasi_ofeilis(boolean _katastasi_ofeilis) {
		this._katastasi_ofeilis = _katastasi_ofeilis;
	}
	public praktoras get_praktoras() {
		return _praktoras;
	}
	public void set_praktoras(praktoras _praktoras) {
		this._praktoras = _praktoras;
	}
	public ofeili get_ofeili() {
		return _ofeili;
	}
	public void set_ofeili(ofeili _ofeili) {
		this._ofeili = _ofeili;
	}
	
	public asfalisi(int _id, float _poso_ofeilis, paketo_asfalisis _paketo_asfalisis, String _enarxi_asfaleias,
			String _lixi_asfaleias, pelatis _pelatis, oxima _oxima, boolean _katastasi_ofeilis, praktoras _praktoras) {
		this._id = _id;
		this._poso_ofeilis = _poso_ofeilis;
		this._paketo_asfalisis = _paketo_asfalisis;
		this._enarxi_asfaleias = _enarxi_asfaleias;
		this._lixi_asfaleias = _lixi_asfaleias;
		this._pelatis = _pelatis;
		this._oxima = _oxima;
		this._katastasi_ofeilis = _katastasi_ofeilis;
		this._praktoras = _praktoras;
		kata_asf.add_asfalisi(this);
		
	}

	public asfalisi ( pelatis _pelatis_,oxima _oxima_,praktoras _praktoras_,paketo_asfalisis _paketo_asfalisis_,int poso_ofeilis, String enarxi_asfaleias,katalogos_ofeilis _katastasi_ofeilis_)
	{
		_pelatis=_pelatis_;
		_oxima=_oxima_;
	}
	


}