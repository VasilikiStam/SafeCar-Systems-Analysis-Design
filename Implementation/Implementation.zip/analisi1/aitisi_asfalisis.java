package analisi1;

public class aitisi_asfalisis extends aitisi {

	katalogos_aitiseon_asfaliseon kata_ait_asf=new katalogos_aitiseon_asfaliseon();

	public aitisi_asfalisis(int _id, float _poso_ofeilis, boolean _katastasi ,paketo_asfalisis _paketo_asfalisis, String _enarxi_asfaleias,
			String _lixi_asfaleias, pelatis _pelatis, oxima _oxima, boolean _katastasi_ofeilis, praktoras _praktoras) {
		super();
		kata_ait_asf.add_aitisis(this);
	}
	
	
	
}