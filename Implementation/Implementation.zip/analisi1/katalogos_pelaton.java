package analisi1;
import java.util.ArrayList;

public class katalogos_pelaton {
	ArrayList<pelatis> pelates;
	
	public katalogos_pelaton() {
		this.pelates=new ArrayList<>();
	}
	public String get_name(int id_pelati) {
		for(pelatis p:pelates) {
			if(p.get_id()==id_pelati) {
				return p.get_onomateponimo();
			}
		}
		return null;
	}
	public void add(pelatis p) {
		pelates.add(p);
	}
	public int[] get_atiximata(pelatis p) {
		for(pelatis pelatis:pelates) {
			if(pelatis.get_id()==p.get_id()) {
				return new int[] {pelatis.get_atiximata()};
			}
		}
		return new int [0];
	}
   public boolean anazitisi(int id_pelati) {
	   for(pelatis p:pelates) {
		   if(p.get_id()==id_pelati) {
			   return true;
			   
		   }
	   }
	   return false;
   }
}
