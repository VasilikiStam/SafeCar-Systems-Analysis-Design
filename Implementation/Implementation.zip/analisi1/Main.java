package analisi1;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//Δημιουργία Πελατών
		if() {
			pelatis Pelatis1 = new pelatis("Maria Papadopoulou","25/07/1979","Tsimiski 72","AB342871",0,3457,false);
			pelatis Pelatis2 = new pelatis("Evanthia Papagianni","19/03/1999","Egnatias 49","XY654321",0,8354,false);
			pelatis Pelatis3 = new pelatis("Vasilis Karagiannis","17/11/1986","Mitropoleos 35","CD987654",0,8129,false);
		
		//Δημιουργία Οχημάτων 
			oxima Oxima1 = new oxima("ΑΒΧ 1234","Mercedes", "GLC",1600,"mavro",4857);
			oxima Oxima2 = new oxima("ΖΥΚ 5678","Subaru", "Forester",1400, "kokkino",5374);
			oxima Oxima3 = new oxima("ΠΤΛ 9012","Ford", "Ranger",1800, "aspro", 6458 );
		
		//Δημιουργία Πακέτων Ασφάλισης
			paketo_asfalisis Paketo_asfalisis1 = new paketo_asfalisis (3450,120);
			paketo_asfalisis Paketo_asfalisis2 = new paketo_asfalisis (7248,60);
			paketo_asfalisis Paketo_asfalisis3 = new paketo_asfalisis (5621,80);
		
		//Δημιουργία Αιτήσεων Ασφάλισης
			aitisi_asfalisis Aitisi1 = new aitisi_asfalisis(Pelatis1,Oxima1,Paketo_asfalisis2,enarksi,liksi,kostos);
			aitisi_asfalisis Aitisi2 = new aitisi_asfalisis(Pelatis2,Oxima2,Paketo_asfalisis1,enarksi,liksi,kostos);
			aitisi_asfalisis Aitisi3 = new aitisi_asfalisis(Pelatis2,Oxima3,Paketo_asfalisis3,enarksi,liksi,kostos);
			
		//Επιβεβαίωση Αιτήσεων 
		
		
		int ep;
		Scanner scanner = new Scanner(System.in);
		
		do {
			System.out.println("1.Dhmioyrgia Aitisis");
			System.out.println("2.Epivevaiosi Aitisis");
			System.out.println("3.Dhmioyrgia Paketou Asfalisis");
			System.out.println("4.Dhmioyrgia Pelati");
			System.out.println("5.Dhmioyrgia Oximatos");
			System.out.println("6.Exodos");
			System.out.println("Parakalo eisagete ton arithmo tis epilogis pou epithumeite");
			
			ep = scanner.nextInt();
			
			if (ep == 1) {
				System.out.println("Parakalw eisagete to id tou pelati.");
				int id1 = scanner.nextInt();
				pelatis Pelatis = katalogos_pelaton.search(id1);
				System.out.println("Parakalw eisagete to id tou oximatos.");
				int id2 = scanner.nextInt();
				oxima Oxima = katalogos_oximaton.search(id2);
				System.out.println("Parakalw eisagete to id tou paketou asfalisis.");
				int id3 = scanner.nextInt();
				paketo_asfalisis paketo_asfalisis = katalogos_paketon_asfalisis.search(id3);
				System.out.println ("Parakalw eisagete thn imerominia enarxis tis asfalisis.");
				String enarksi = scanner.next();
				System.out.println("Parakalw eisagete thn imerominia lixis tis asfalisis.");
				String liksi = scanner.next();
				
			 aitisi_asfalisis Aitisi = new aitisi_asfalisis(pelatis,oxima,paketo_asfalisis,enarksi,liksi,kostos);
			 
			 System.out.println ("Epituxis dimiourgia Asfalisis!");
			}
			else if (ep == 2) {
				System.out.println("Parakalw eisagete to id ths Aitisis pou thelete na epivevaiosete.");
				int id = scanner.nextInt();
				
				// Επιβεβαιωση
				
				System.out.println ("Epituxis epivevaiosi Aitisis!");
			}
			else if (ep == 3) {
				System.out.println("Parakalw eisagete to id tou neou paketou.");
				int id = scanner.nextInt();
				System.out.println("Parakalw eisagete to kostos tou neou paketou.");
				float kostos = scanner.nextFloat();
				paketo_asfalisis Paket_Asfalisis = new paketo_asfalisis (id, kostos,0);
				
				System.out.println ("Epituxis dimiourgia Paketou Asfalisis!");
				
			}
			else if (ep == 4) {
				System.out.println("Eisagete to onomateponymo tou pelati.");
				String onomateponimo = scanner.next();
				System.out.println("Eisagete thn imerominia gennisis tou pelati.");
				String imerominia_gennisis = scanner.next();
				System.out.println("Eisagete th diefthinsi tou pelati.");
				String diefthinsi = scanner.next();
				System.out.println("Eisagete ton arithmo diplomatos odigisis tou pelati.");
				String ar_dip_odigisis = scanner.next();
				System.out.println("Parakalw eisagete to id tou neou pelati.");
				int id = scanner.nextInt();
				
				pelatis Pelatis = new pelatis(onomateponimo,imerominia_gennisis,diefthinsi,ar_dip_odigisis,0,id,false);
			
				System.out.println ("New Customer has been created");
				System.out.println ("Epituxis dimiourgia Pelath!");
				
			}
			else if (ep == 5) {
				System.out.println("Eisagete ton arithmo kykloforias tou oximatos.");
				String ar_kikloforias = scanner.next();
				System.out.println("Eisagete th marka tou oximatos.");
				String marka = scanner.next();
				System.out.println("Eisagete to montelo tou oximatos.");
				String montelo = scanner.next();
				System.out.println("Parakalw eisagete ta kibika ekatosta tou oximatos.");
				float kibika_ek = scanner.nextFloat();
				System.out.println("Eisagete to xroma tou oximatos.");
				String xroma = scanner.next();
				System.out.println("Parakalw eisagete to id tou neou oximatos.");
				int id = scanner.nextInt();
				
				oxima Oxima = new Oxima(ar_kikloforias,marka,montelo,kibika_ek,xroma,id);	
				
				System.out.println ("New Vehicle has been created");
				System.out.println ("Epituxis dimiourgia Oximatos!");
			
			}
			else if (ep == 6) {
				
			}
			else {
				System.out.println("Auti h epilogi den einai diathesimi");
			}
		
		}while (ep != 6); 
		
		 scanner.close();
     } 
}
