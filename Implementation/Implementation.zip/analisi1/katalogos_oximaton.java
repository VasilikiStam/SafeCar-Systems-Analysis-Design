package analisi1;
 
import java.util.*;

public class katalogos_oximaton {
	
	ArrayList<oxima> oximata;
	
	public katalogos_oximaton() {
		oximata=new ArrayList<oxima>();
	}
	
	public void add_oxima( oxima _oxima)
	{
		oximata.add(_oxima);
	}
	
	public boolean check(int id)
	{
		for(int i=0; i<oximata.size();i++)
			if(oximata.get(i).getId() == id)
				return true;
		return false;
	}
	
	public oxima search(int id)
	{
		for(int i=0; i<oximata.size();i++) {
			if(oximata.get(i).getId() == id)
				return oximata.get(i);
		}
		
	}
	
	public void remove(oxima _oxima)
	{
		oximata.remove(_oxima);
	}

}
