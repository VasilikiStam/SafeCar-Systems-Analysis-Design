package analisi1;

import java.util.ArrayList;

public class katalogos_aitiseon_apozimiosis extends katalogos_aitiseon{
	
	private ArrayList<aitisi_apozimiosis> aitiseis_apozimiosis = new ArrayList<aitisi_apozimiosis>();
	
	public katalogos_aitiseon_apozimiosis() {}


	
	
	}
