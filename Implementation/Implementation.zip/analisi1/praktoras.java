package analisi1;

public class praktoras {
	
	

}
