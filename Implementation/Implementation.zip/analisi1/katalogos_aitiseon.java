package analisi1;

import java.util.*;

public class katalogos_aitiseon {
	
	ArrayList<aitisi> aitiseis ;
	
	public katalogos_aitiseon() {
		aitiseis =new ArrayList<aitisi>();
	}
	
	public void add_aitisis( aitisi _aitisi)
	{
		aitiseis.add(_aitisi);
	}
	
	public boolean check(int id)
	{
		for(int i=0; i<aitiseis.size();i++)
			if(aitiseis.get(i).get_id() == id)
				return true;
		return false;
	}
	
	public aitisi search(int id)
	{
		for(int i=0; i<aitiseis.size();i++)
			if(aitiseis.get(i).get_id() == id)
				return aitiseis.get(i);
	}
	
	public void remove(aitisi _aitisi)
	{
		aitiseis.remove(_aitisi);
	}

}
